
extern zend_class_entry *phalcon_dispatcher_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Dispatcher_Exception);

