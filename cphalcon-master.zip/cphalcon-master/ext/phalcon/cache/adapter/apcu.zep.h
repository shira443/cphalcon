
extern zend_class_entry *phalcon_cache_adapter_apcu_ce;

ZEPHIR_INIT_CLASS(Phalcon_Cache_Adapter_Apcu);

